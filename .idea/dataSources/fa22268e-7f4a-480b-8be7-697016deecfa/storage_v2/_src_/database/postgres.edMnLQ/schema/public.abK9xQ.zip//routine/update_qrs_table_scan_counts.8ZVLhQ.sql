create function update_qrs_table_scan_counts() returns trigger
    security definer
    language plpgsql
as
$$
begin

    update qrs
    set scan_counts = qrs.scan_counts + 1
    where id = NEW.qr_id;
    return NEW;
end;
$$;

alter function update_qrs_table_scan_counts() owner to postgres;

grant execute on function update_qrs_table_scan_counts() to anon;

grant execute on function update_qrs_table_scan_counts() to authenticated;

grant execute on function update_qrs_table_scan_counts() to service_role;

