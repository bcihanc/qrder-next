create function hypertable_size(hypertable regclass) returns bigint
    strict
    SET search_path = pg_catalog, pg_temp
    language sql
as
$$
   -- One row per data node is returned (in case of a distributed
   -- hypertable), so sum them up:
   SELECT sum(total_bytes)::bigint
   FROM extensions.hypertable_detailed_size(hypertable);
$$;

alter function hypertable_size(regclass) owner to supabase_admin;

grant execute on function hypertable_size(regclass) to postgres with grant option;

