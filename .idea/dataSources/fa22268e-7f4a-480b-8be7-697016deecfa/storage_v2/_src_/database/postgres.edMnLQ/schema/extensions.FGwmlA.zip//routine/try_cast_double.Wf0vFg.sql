create function try_cast_double(inp text) returns double precision
    immutable
    language plpgsql
as
$$
  BEGIN
    BEGIN
      RETURN inp::double precision;
    EXCEPTION
      WHEN OTHERS THEN RETURN NULL;
    END;
  END;
$$;

alter function try_cast_double(text) owner to postgres;

grant execute on function try_cast_double(text) to dashboard_user;

