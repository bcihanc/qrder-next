create function url_decode(data text) returns bytea
    immutable
    language sql
as
$$
WITH t AS (SELECT translate(data, '-_', '+/') AS trans),
     rem AS (SELECT length(t.trans) % 4 AS remainder FROM t) -- compute padding size
    SELECT decode(
        t.trans ||
        CASE WHEN rem.remainder > 0
           THEN repeat('=', (4 - rem.remainder))
           ELSE '' END,
    'base64') FROM t, rem;
$$;

alter function url_decode(text) owner to postgres;

grant execute on function url_decode(text) to dashboard_user;

